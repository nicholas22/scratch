package com.typesafety.myfxaeronsbe;

import com.typesafety.myfxaeronsbe.model.FxMsgDecoder;
import com.typesafety.myfxaeronsbe.model.FxMsgEncoder;
import com.typesafety.myfxaeronsbe.model.MessageHeaderDecoder;
import com.typesafety.myfxaeronsbe.model.MessageHeaderEncoder;
import org.agrona.BufferUtil;
import org.agrona.MutableDirectBuffer;
import org.agrona.concurrent.UnsafeBuffer;

import java.nio.ByteBuffer;

public class Main {
    public static void main(String[] args) throws Exception {
        // buffer to use for encoding

//        final ByteBuffer byteBuffer = ByteBuffer.allocateDirect(4096);
//        final UnsafeBuffer directBuffer = new UnsafeBuffer(byteBuffer);
        // better as aligned?
        final UnsafeBuffer directBuffer = new UnsafeBuffer(BufferUtil.allocateDirectAligned(256, 64));

        // msg header, specified in model
        MessageHeaderEncoder headerEncoder = new MessageHeaderEncoder();
        MessageHeaderDecoder headerDecoder = new MessageHeaderDecoder();

        // msg
        FxMsgEncoder fxMsg = new FxMsgEncoder();
        FxMsgDecoder decoder = new FxMsgDecoder();

        byte[] ccy = "USDGBP".getBytes(FxMsgEncoder.ccypairCharacterEncoding()); // ascii

//        System.out.println("nullval="+FxMsgEncoder.priceNullValue()); See 'adkapur' https://github.com/FIXTradingCommunity/fix-simple-binary-encoding/issues/31
        fxMsg.wrapAndApplyHeader(directBuffer, 0, headerEncoder);
        fxMsg
                .price(123)
                .putCcypair(ccy, 0) // byte[]
                .exchange("LME"); // string

        fxMsg.pricesCount(2)
                .next().price(1000)
                .next().price(2000);

        MutableDirectBuffer mbb = fxMsg.buffer();

        int encodedLength = MessageHeaderEncoder.ENCODED_LENGTH + fxMsg.encodedLength();

        System.out.println("Encoded len=" + encodedLength);

        for (int i = 0; i < encodedLength; i++) {
            String a = mbb.getByte(i) + " -> " + new String(new byte[]{mbb.getByte(i)});
            String b = directBuffer.getByte(i) + " -> " + new String(new byte[]{directBuffer.getByte(i)});
            System.out.println(a + " | " + b);
        }

        // decode header
        int bufferOffset = 0;
        headerDecoder.wrap(directBuffer, bufferOffset);

        // Lookup the applicable flyweight to decode this type of message based on templateId and version.
        final int templateId = headerDecoder.templateId();
        if (templateId != FxMsgEncoder.TEMPLATE_ID) {
            throw new IllegalStateException("Template ids do not match");
        }

        final int actingBlockLength = headerDecoder.blockLength();
        final int actingVersion = headerDecoder.version();
        // advance to body
        bufferOffset += headerDecoder.encodedLength();

        decoder.wrap(directBuffer, bufferOffset, actingBlockLength, actingVersion);

        System.out.println(decoder.ccypair());
        System.out.println(decoder.price());
        System.out.println(decoder.exchange());
        int i=0;
        for (final FxMsgDecoder.PricesDecoder pd : decoder.prices()) {
            i += 1;
            System.out.println(i+": "+pd.price());
        }
    }
}
