package com.typesafety.myfxaeronsbe.aeron;

import io.aeron.driver.MediaDriver;
import io.aeron.driver.ThreadingMode;
import org.agrona.concurrent.BusySpinIdleStrategy;
import org.agrona.concurrent.ShutdownSignalBarrier;
import org.agrona.concurrent.YieldingIdleStrategy;

import static org.agrona.SystemUtil.loadPropertiesFiles;

/**
 * Sample setup for a {@link MediaDriver} that is configured for low latency communications.
 */
public class LowLatencyMediaDriver {
    public static void main(final String[] args) {
        loadPropertiesFiles(args);

        final MediaDriver.Context ctx = new MediaDriver.Context()
                .termBufferSparseFile(false)
                .threadingMode(ThreadingMode.DEDICATED)
                .conductorIdleStrategy(new YieldingIdleStrategy()) // BusySpin
                .receiverIdleStrategy(new YieldingIdleStrategy())
                .senderIdleStrategy(new YieldingIdleStrategy());
System.out.println(ctx.mtuLength());
        try (MediaDriver ignored = MediaDriver.launch(ctx)) {
            System.out.println("Starting...");
            new ShutdownSignalBarrier().await();

            System.out.println("Shutdown Driver...");
        }
    }
}
