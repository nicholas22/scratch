/* Generated SBE (Simple Binary Encoding) message codec */
package com.typesafety.myfxaeronsbe.model;

@javax.annotation.Generated(value = { "uk.co.real_logic.sbe.generation.java.JavaGenerator" })
public enum MetaAttribute
{
    EPOCH,
    TIME_UNIT,
    SEMANTIC_TYPE,
    PRESENCE
}
